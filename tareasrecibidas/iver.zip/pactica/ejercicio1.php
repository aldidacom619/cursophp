<html>
	<head>
	</head>
	<title>PRACTICA_3</title>
	</head>
	<body>
		<h3>VERIFICAR los numeros </h3>
		<form action="contar.php" method="get">
			<label>NUMERO A VERIFICAR : </label><br>
			<input type="text" name="n1"><br>
			<input type="text" name="n2"><br>
			<input type="text" name="n3"><br>
			<input type="text" name="n4"><br>
			<input type="text" name="n5"><br>
			<input type="text" name="n6"><br>
			<input type="text" name="n7"><br>
			<input type="text" name="n8"><br>
			<input type="text" name="n9"><br>
			<input type="text" name="n10"><br>
			<input type="submit" name="btnGuardar" value="ENVIAR"><br>
		</form>
	
</body>
<html>