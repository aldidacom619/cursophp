<?php
$C1=0;
$C2=0;
$C3=0;
$C4=0;
$C5=0;
$C6=0;
$C7=0;
$C8=0;
$C9=0;
$C10=0;
$N[0]=$_GET['n1'];
$N[1]=$_GET['n2'];
$N[2]=$_GET['n3'];
$N[3]=$_GET['n4'];
$N[4]=$_GET['n5'];
$N[5]=$_GET['n6'];
$N[6]=$_GET['n7'];
$N[7]=$_GET['n8'];
$N[8]=$_GET['n9'];
$N[9]=$_GET['n10'];
for($i=0;$i<=9;$i++)
	switch($N[$i])
{
		case $N[0]: $C1++;break;
		case $N[1]: $C2++;break;
		case $N[2]: $C3++;break;
		case $N[3]: $C4++;break;
		case $N[4]: $C5++;break;
		case $N[5]: $C6++;break;
		case $N[6]: $C7++;break;
		case $N[7]: $C8++;break;
		case $N[8]: $C9++;break;
		case $N[9]: $C10++;break;
	}
$sw=0;

$mayor=$C1;
$nm=$N[0];
if($C2>$mayor)
{	$mayor=$C2;
	$sw=1;
	$nm=$N[1];}
if($C3>$mayor)
{	$mayor=$C3;
	$sw=1;
	$nm=$N[2];}
if($C4>$mayor)
	{	$mayor=$C4;
		$sw=1;
	$nm=$N[3];}
if($C5>$mayor)
	{	$mayor=$C5;
		$sw=1;
	$nm=$N[4];}
if($C6>$mayor)
	{	$mayor=$C6;
		$sw=1;
	$nm=$N[5];}
if($C7>$mayor)
	{	$mayor=$C7;
		$sw=1;
	$nm=$N[6];}
if($C8>$mayor)
	{	$mayor=$C8;
		$sw=1;
	$nm=$N[7];}
if($C9>$mayor)
	{	$mayor=$C9;
		$sw=1;
	$nm=$N[8];}
if($C10>$mayor)
	{	$mayor=$C10;
		$sw=1;
	$nm=$N[9];}
if($sw==0)
	echo "ningun numero se repite";
else
echo "el numero que mas se repite es ".$nm;


?>