<?php
$num=$_GET['numero'];
$CD=0;
$CN=1;
while ($CN<=$num) {
	if($num%$CN==0)
		$CD++;
	$CN++;
}
if($CD==2){
	echo "el numero".$num."es primo";
}
else{
	echo "el numero".$num."no es primo";
}

?>