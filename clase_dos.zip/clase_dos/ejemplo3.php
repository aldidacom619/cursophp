<?php
echo "OPERADOR IF";
echo "<br>";

$comida = "CHICHARON";




echo "<br>";
echo "<br>";
if ($comida == "CHICHARON") 
{
	echo "DIEGO COMERA CHICHARON";
}
elseif ($comida == "FRICASE") {
	echo "DIEGO COMERA FRICASE";
}
else
{
	echo "DIEGO COMERA NADA";
}

echo "<br>";
echo "<br>";
/*
$numero3 = 30;
if($numero3%2 == 0)
{
	echo "el numero".$numero3." es par";
}	
else
{
	echo "el numero".$numero3."es impar";
}*/

?>