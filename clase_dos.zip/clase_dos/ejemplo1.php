<?php
  /*echo "hola curso de php clase 2";
  echo "<br>";
  echo "<br>";
  echo "<br>";
  echo "texto dos";*/
  echo "hola curso de php clase 2";
  echo "<br>";
  echo "<br>";
  echo "<br>";
  echo "texto dos";
  //declaracion de variables

    $variable1 = "HOLA COMO ESTAS?";
	$variable2 = 15;
	$variable3 = 10.7;
	$variable4 = TRUE;

	var_dump($variable1);
	echo "<br>";
	var_dump($variable2);
	echo "<br>";	
	var_dump($variable3);
	echo "<br>";
	var_dump($variable4);
	echo "<br>";echo "<br>";
	


   




?>