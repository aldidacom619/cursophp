<?php
	
	$cont = 10;

	
	for ($i=0; $i < $cont; $i++) { 
		echo "contador igual a: ". $i."<br>";
	}

	echo "<br>";
	$cont = 10;
	for ($i=$cont; $i > 0; $i--) { 
		echo "contador igual a: ". $i."<br>";
	}


?>