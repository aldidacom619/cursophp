function nuevoregistro()
{
	//alert("holaa");
	$('#datousuario').modal('show');
}