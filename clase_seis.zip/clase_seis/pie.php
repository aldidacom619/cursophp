</body>
<footer>
  <script src="recursos/jsd/jquery.min.js"></script>
  <script src="recursos/bootstrap-4.3.1/dist/js/bootstrap.min.js"></script>
  <script src="recursos/bootstrap-4.3.1/dist/js/popper.min.js"></script>
</footer>
</html>