<?php
	
  //COMENTARIO 1
	echo "HOLA PRIMER DIA DE CLASES CON 'PHP'";
	echo "<br>";
/*	echo "HOLA PRIMER DIA DE CLASES CON PHP";
	echo "<br>";
	echo "HOLA PRIMER DIA DE CLASES CON PHP";*/

	// VARIABLES

	$variable1 = "HOLA COMO ESTAS?";
	$variable2 = 15;
	$variable3 = 10.7;
	$variable4 = TRUE;

	var_dump($variable1);
	echo "<br>";
	var_dump($variable2);
	echo "<br>";	
	var_dump($variable3);
	echo "<br>";
	var_dump($variable4);
	
?>