<?php
echo "variables de tipo array";
echo "<br>";
$array	 = array('DIEGO','DAZA',2019,"78720504","ORH+");

echo "valor en la posicion 0: ".$array[0];

echo "ASIGNACION DE VALORES A UN ARRAY";
echo "<br>";

$persona[0]= "DAZA";
$persona[1]= "DIEGO";


var_dump($persona);

?>