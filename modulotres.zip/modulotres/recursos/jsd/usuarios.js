var base_url;
var alertaValidacion = '';
var validarci = false;
function baseurl(enlace)
{ 
  base_url = enlace;  
  alert(baseurl);
}