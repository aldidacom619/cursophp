<?php
/**
 * 
 */
class Reportes extends CI_Controller
{	
	function __construct()
	{
		parent::__construct();
		$this->_is_logued_in();
		$this->load->model('Usuarios_model');
		$this->load->helper('form');
		$this->load->library('pdf2');
		$this->load->helper('date');
	}
	function _is_logued_in()
	{
		$is_logued_in = $this->session->userdata('is_logued_in');
		if($is_logued_in != TRUE)
		{
			redirect('loguen');
		}
	}
	function imprimirprueba()
	{
		$pdf = new Pdf2();
		$pdf->cabecera = 1;
		$pdf->titulo = "Reportes de Usuarios";
		$fecha_hoy = $pdf->fechacompleta();
		$pdf->fecha = "Fecha de Impresión: ".$fecha_hoy;
		$pdf->SetFont('Arial','B',12);
		$encabezados = array(
			'Nro.',
			'NOMBRE',
			'APELLIDO',
			'CORREO',
			'TELEFONO'
		);
		$w = array(10,38,60,50,40);
		foreach ($encabezados as $val) 
		{
		 	$encabezados_[] = iconv('UTF-8', 'windows-1252',$val);
		} 
		$pdf->setEncabezadoG($encabezados_);
		$pdf->setWidthsG($w);
		$pdf->AddPage('P','Letter',null,null);				
		$pdf->SetFont('Arial','',10);
		$pdf->SetAligns(array('R','C','C','L','R'));
		$pdf->SetFillColor(255,255,255);
		$pdf->SetTextColor(0);
		$datos = $this->Usuarios_model->getusuarios();
		$num = 1;
		if(!empty($datos))
		{
			foreach ($datos as $valor) 
			{
				$s = array(
					$num++,
					iconv('UTF-8', 'windows-1252', $valor->nombre),
					iconv('UTF-8', 'windows-1252', $valor->apellido),
					iconv('UTF-8', 'windows-1252', $valor->correo),
					iconv('UTF-8', 'windows-1252', $valor->telefono)
				);
				$pdf->Row($s,true,'',5);
			}
		}
		$pdf->Output();
	}

}
?>