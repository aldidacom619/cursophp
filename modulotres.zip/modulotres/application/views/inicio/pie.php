</body>
<footer>
  <script src="<?php echo base_url()?>recursos/jsd/jquery.min.js"></script>
  <script src="<?php echo base_url()?>recursos/bootstrap-4.3.1/dist/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>recursos/bootstrap-4.3.1/dist/js/popper.min.js"></script>
</footer>
</html>